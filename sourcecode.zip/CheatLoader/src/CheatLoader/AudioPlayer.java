package CheatLoader;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class AudioPlayer {
	
	public static void playInject()
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		File injectaudio = new File("inject.wav");
		AudioInputStream buttonStream = AudioSystem.getAudioInputStream(injectaudio);
		Clip injectfct = AudioSystem.getClip();
		injectfct.open(buttonStream);
		injectfct.start();
	}

	public static void playInjected()
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		File injectedaudio = new File("injected.wav");
		AudioInputStream injectStream = AudioSystem.getAudioInputStream(injectedaudio);
		Clip injectedfct = AudioSystem.getClip();
		injectedfct.open(injectStream);
		injectedfct.start();
	}

	public static void playButton()
			throws UnsupportedAudioFileException, IOException, LineUnavailableException {

		File buttonaudio = new File("button.wav");
		AudioInputStream buttonStream = AudioSystem.getAudioInputStream(buttonaudio);
		Clip buttonfct = AudioSystem.getClip();
		buttonfct.open(buttonStream);
		buttonfct.start();
	}

}
